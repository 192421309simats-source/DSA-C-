import { useEffect, useMemo, useState } from "react";
import {
  AlertCircle, BarChart3, Bell, CheckCircle2, ClipboardList, FileText,
  Home, LogIn, MapPin, Menu, PlusCircle, Search, ShieldCheck, User,
  Users, X, Clock3, Building2, ChevronRight
} from "lucide-react";

type Status = "Submitted" | "Under Review" | "Assigned" | "In Progress" | "Resolved";

type Complaint = {
  id: string;
  title: string;
  description: string;
  category: string;
  priority: "Low" | "Medium" | "High" | "Critical";
  status: Status;
  citizen: string;
  ward: string;
  department: string;
  date: string;
};

const initialComplaints: Complaint[] = [
  {
    id: "CMP-1001", title: "Pothole near Main Road", description: "Large pothole causing traffic difficulty.",
    category: "Road Damage", priority: "High", status: "In Progress",
    citizen: "Arun Kumar", ward: "Ward 12", department: "Roads & Transport", date: "03 Sep 2026"
  },
  {
    id: "CMP-1002", title: "Streetlight not working", description: "Streetlight has been off for three nights.",
    category: "Streetlight", priority: "Medium", status: "Assigned",
    citizen: "Meena S", ward: "Ward 7", department: "Electrical Services", date: "02 Sep 2026"
  },
  {
    id: "CMP-1003", title: "Irregular water supply", description: "No water supply during morning hours.",
    category: "Water Supply", priority: "Critical", status: "Under Review",
    citizen: "Rahul P", ward: "Ward 4", department: "Water Supply", date: "01 Sep 2026"
  },
  {
    id: "CMP-1004", title: "Waste collection missed", description: "Household waste has not been collected.",
    category: "Waste Management", priority: "Medium", status: "Resolved",
    citizen: "Divya R", ward: "Ward 9", department: "Sanitation", date: "31 Aug 2026"
  }
];

const departments = ["Roads & Transport", "Water Supply", "Sanitation", "Drainage", "Electrical Services"];

const categoryDepartment: Record<string, string> = {
  "Road Damage": "Roads & Transport",
  "Water Supply": "Water Supply",
  "Waste Management": "Sanitation",
  "Drainage": "Drainage",
  "Streetlight": "Electrical Services"
};

function App() {
  const [page, setPage] = useState("dashboard");
  const [mobile, setMobile] = useState(false);
  const [complaints, setComplaints] = useState<Complaint[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("urbanComplaints") || "null") || initialComplaints;
    } catch { return initialComplaints; }
  });
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState("");

  useEffect(() => {
    localStorage.setItem("urbanComplaints", JSON.stringify(complaints));
  }, [complaints]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return complaints.filter(c =>
      [c.id, c.title, c.category, c.status, c.ward, c.department].join(" ").toLowerCase().includes(q)
    );
  }, [complaints, search]);

  const stats = {
    total: complaints.length,
    pending: complaints.filter(c => !["Resolved"].includes(c.status)).length,
    progress: complaints.filter(c => ["Assigned", "In Progress"].includes(c.status)).length,
    resolved: complaints.filter(c => c.status === "Resolved").length
  };

  function addComplaint(data: Omit<Complaint, "id" | "status" | "date" | "department">) {
    const newComplaint: Complaint = {
      ...data,
      id: `CMP-${1000 + complaints.length + 1}`,
      status: "Submitted",
      date: new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }),
      department: categoryDepartment[data.category] || "General Services"
    };
    setComplaints(prev => [newComplaint, ...prev]);
    setShowForm(false);
    setPage("complaints");
  }

  function updateStatus(id: string, status: Status) {
    setComplaints(prev => prev.map(c => c.id === id ? { ...c, status } : c));
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand" onClick={() => setPage("dashboard")}>
          <div className="brand-icon"><Building2 size={23}/></div>
          <div><strong>UrbanServe</strong><span>Complaint & Service Portal</span></div>
        </div>
        <div className="top-actions">
          <button className="icon-btn"><Bell size={19}/><i/></button>
          <div className="profile"><div className="avatar">AK</div><div><b>Admin User</b><small>Administrator</small></div></div>
          <button className="mobile-menu icon-btn" onClick={() => setMobile(!mobile)}><Menu/></button>
        </div>
      </header>

      <div className="layout">
        <aside className={mobile ? "sidebar open" : "sidebar"}>
          <nav>
            <NavItem icon={<Home/>} label="Dashboard" active={page==="dashboard"} onClick={()=>{setPage("dashboard");setMobile(false)}}/>
            <NavItem icon={<ClipboardList/>} label="Complaints" active={page==="complaints"} onClick={()=>{setPage("complaints");setMobile(false)}}/>
            <NavItem icon={<PlusCircle/>} label="Register Complaint" active={page==="register"} onClick={()=>{setPage("register");setMobile(false)}}/>
            <NavItem icon={<Search/>} label="Track Complaint" active={page==="track"} onClick={()=>{setPage("track");setMobile(false)}}/>
            <NavItem icon={<Users/>} label="Departments" active={page==="departments"} onClick={()=>{setPage("departments");setMobile(false)}}/>
            <NavItem icon={<BarChart3/>} label="Reports" active={page==="reports"} onClick={()=>{setPage("reports");setMobile(false)}}/>
          </nav>
          <div className="sidebar-bottom">
            <div className="help-box"><ShieldCheck size={22}/><b>System protected</b><span>All complaint records are stored locally.</span></div>
            <button className="logout"><LogIn size={18}/> Sign out</button>
          </div>
        </aside>

        <main className="main">
          {page === "dashboard" && <Dashboard stats={stats} complaints={complaints} onNew={()=>setShowForm(true)} onPage={setPage}/>}
          {page === "complaints" && <Complaints complaints={filtered} search={search} setSearch={setSearch} onStatus={updateStatus}/>}
          {page === "register" && <Register onSubmit={addComplaint}/>}
          {page === "track" && <Track complaints={complaints}/>}
          {page === "departments" && <Departments complaints={complaints}/>}
          {page === "reports" && <Reports complaints={complaints}/>}
        </main>
      </div>

      {showForm && <Modal onClose={()=>setShowForm(false)}><Register onSubmit={addComplaint}/></Modal>}
    </div>
  );
}

function NavItem({icon,label,active,onClick}:{icon:React.ReactNode;label:string;active:boolean;onClick:()=>void}) {
  return <button className={active ? "nav-item active" : "nav-item"} onClick={onClick}>{icon}<span>{label}</span><ChevronRight className="nav-arrow"/></button>;
}

function Dashboard({stats, complaints, onNew, onPage}:{stats:any;complaints:Complaint[];onNew:()=>void;onPage:(p:string)=>void}) {
  return <div className="content">
    <div className="page-head">
      <div><p className="eyebrow">OVERVIEW</p><h1>Good morning, Admin 👋</h1><p className="muted">Monitor complaints and coordinate urban services from one place.</p></div>
      <button className="primary" onClick={onNew}><PlusCircle size={18}/> Register Complaint</button>
    </div>

    <section className="stats-grid">
      <Stat icon={<FileText/>} label="Total Complaints" value={stats.total} note="All registered complaints"/>
      <Stat icon={<Clock3/>} label="Pending" value={stats.pending} note="Need attention"/>
      <Stat icon={<ClipboardList/>} label="In Progress" value={stats.progress} note="Currently assigned"/>
      <Stat icon={<CheckCircle2/>} label="Resolved" value={stats.resolved} note="Successfully completed"/>
    </section>

    <div className="dashboard-grid">
      <section className="card">
        <div className="card-head"><div><h2>Recent Complaints</h2><p>Latest citizen service requests</p></div><button className="text-btn" onClick={()=>onPage("complaints")}>View all <ChevronRight size={16}/></button></div>
        <ComplaintTable complaints={complaints.slice(0,5)} compact/>
      </section>
      <section className="card">
        <div className="card-head"><div><h2>Priority Alerts</h2><p>Complaints requiring quick action</p></div></div>
        <div className="alerts">
          {complaints.filter(c=>c.priority==="Critical"||c.priority==="High").slice(0,4).map(c=>
            <div className="alert" key={c.id}><div className="alert-icon"><AlertCircle size={19}/></div><div><b>{c.title}</b><span>{c.id} · {c.ward}</span></div><Priority value={c.priority}/></div>
          )}
          {complaints.filter(c=>c.priority==="Critical"||c.priority==="High").length===0 && <Empty text="No high-priority alerts."/>}
        </div>
      </section>
    </div>

    <section className="card workflow">
      <div className="card-head"><div><h2>Complaint Workflow</h2><p>Standard process from registration to resolution</p></div></div>
      <div className="steps">
        {["Register","Review","Assign Department","Resolve","Close"].map((s,i)=><div className="step" key={s}><div className="step-circle">{i+1}</div><b>{s}</b>{i<4&&<div className="step-line"/>}</div>)}
      </div>
    </section>
  </div>
}

function Stat({icon,label,value,note}:{icon:React.ReactNode;label:string;value:number;note:string}) {
  return <div className="stat-card"><div className="stat-icon">{icon}</div><div><span>{label}</span><strong>{value}</strong><small>{note}</small></div></div>
}

function Complaints({complaints,search,setSearch,onStatus}:{complaints:Complaint[];search:string;setSearch:(v:string)=>void;onStatus:(id:string,s:Status)=>void}) {
  return <div className="content">
    <div className="page-head"><div><p className="eyebrow">MANAGEMENT</p><h1>Complaints</h1><p className="muted">View, compare and update citizen complaints.</p></div></div>
    <section className="card">
      <div className="toolbar"><div className="search"><Search size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search by ID, title, category, ward..."/></div><span className="result-count">{complaints.length} records</span></div>
      <ComplaintTable complaints={complaints} onStatus={onStatus}/>
    </section>
  </div>
}

function ComplaintTable({complaints,compact=false,onStatus}:{complaints:Complaint[];compact?:boolean;onStatus?:(id:string,s:Status)=>void}) {
  return <div className="table-wrap"><table><thead><tr><th>ID</th><th>Complaint</th><th>Category</th><th>Priority</th><th>Status</th><th>Department</th>{!compact&&<th>Update</th>}</tr></thead>
    <tbody>{complaints.map(c=><tr key={c.id}><td><b className="id">{c.id}</b></td><td><div className="complaint-name"><b>{c.title}</b><small>{c.citizen} · {c.ward}</small></div></td><td>{c.category}</td><td><Priority value={c.priority}/></td><td><StatusBadge value={c.status}/></td><td>{c.department}</td>{!compact&&<td>{onStatus&&<select value={c.status} onChange={e=>onStatus(c.id,e.target.value as Status)}>{["Submitted","Under Review","Assigned","In Progress","Resolved"].map(s=><option key={s}>{s}</option>)}</select>}</td>}</tr>)}</tbody>
  </table>{complaints.length===0&&<Empty text="No complaints found."/>}</div>
}

function Priority({value}:{value:Complaint["priority"]}) { return <span className={"priority "+value.toLowerCase()}>{value}</span> }
function StatusBadge({value}:{value:Status}) { return <span className={"status "+value.toLowerCase().replaceAll(" ","-")}>{value}</span> }
function Empty({text}:{text:string}) { return <div className="empty"><Search size={26}/><b>{text}</b></div> }

function Register({onSubmit}:{onSubmit:(data:Omit<Complaint,"id"|"status"|"date"|"department">)=>void}) {
  const [form,setForm]=useState({title:"",description:"",category:"Road Damage",priority:"Medium" as Complaint["priority"],citizen:"",ward:""});
  const change=(key:string,value:string)=>setForm(f=>({...f,[key]:value}));
  return <div className="form-page"><div className="page-head"><div><p className="eyebrow">CITIZEN SERVICES</p><h1>Register a Complaint</h1><p className="muted">Provide the issue details so the right department can respond quickly.</p></div></div>
    <form className="card form-card" onSubmit={e=>{e.preventDefault();if(form.title&&form.description&&form.citizen&&form.ward)onSubmit(form)}}><div className="form-section"><h2>Complaint Details</h2><p>Describe the issue clearly.</p>
      <label>Complaint Title<input required value={form.title} onChange={e=>change("title",e.target.value)} placeholder="e.g. Pothole near Main Road"/></label>
      <div className="two"><label>Category<select value={form.category} onChange={e=>change("category",e.target.value)}>{Object.keys(categoryDepartment).map(x=><option key={x}>{x}</option>)}</select></label>
      <label>Priority<select value={form.priority} onChange={e=>change("priority",e.target.value)}><option>Low</option><option>Medium</option><option>High</option><option>Critical</option></select></label></div>
      <label>Description<textarea required value={form.description} onChange={e=>change("description",e.target.value)} placeholder="Explain the problem, location and impact..."/></label></div>
      <div className="form-section"><h2>Citizen Information</h2><div className="two"><label>Citizen Name<input required value={form.citizen} onChange={e=>change("citizen",e.target.value)} placeholder="Full name"/></label><label>Ward<input required value={form.ward} onChange={e=>change("ward",e.target.value)} placeholder="e.g. Ward 12"/></label></div></div>
      <div className="form-footer"><span><MapPin size={17}/> Department will be recommended automatically from the category.</span><button className="primary" type="submit"><CheckCircle2 size={18}/> Submit Complaint</button></div>
    </form>
  </div>
}

function Track({complaints}:{complaints:Complaint[]}) {
  const [id,setId]=useState(""); const [found,setFound]=useState<Complaint|null>(null);
  return <div className="content"><div className="page-head"><div><p className="eyebrow">STATUS TRACKING</p><h1>Track Complaint</h1><p className="muted">Enter a complaint ID to view its current status.</p></div></div>
    <section className="card track-card"><div className="track-search"><input value={id} onChange={e=>setId(e.target.value.toUpperCase())} placeholder="Enter ID e.g. CMP-1001"/><button className="primary" onClick={()=>setFound(complaints.find(c=>c.id===id)||null)}><Search size={18}/> Track</button></div>
    {found ? <div className="tracking-result"><div className="track-title"><div><span className="eyebrow">{found.id}</span><h2>{found.title}</h2><p>{found.category} · {found.department} · {found.ward}</p></div><StatusBadge value={found.status}/></div><div className="timeline">{["Submitted","Under Review","Assigned","In Progress","Resolved"].map((s,i)=>{const current=["Submitted","Under Review","Assigned","In Progress","Resolved"].indexOf(found.status);return <div className={i<=current?"timeline-item done":"timeline-item"} key={s}><div className="timeline-dot">{i<current?<CheckCircle2 size={15}/>:i===current?<Clock3 size={15}/>:i+1}</div><div><b>{s}</b><small>{i<=current?"Completed / current stage":"Waiting for previous stage"}</small></div></div>})}</div></div> : id && <Empty text="Complaint ID not found. Check the ID and try again."/>}
    </section>
  </div>
}

function Departments({complaints}:{complaints:Complaint[]}) {
  return <div className="content"><div className="page-head"><div><p className="eyebrow">SERVICE NETWORK</p><h1>Departments</h1><p className="muted">Department workload and complaint assignment overview.</p></div></div>
    <div className="dept-grid">{departments.map(d=>{const list=complaints.filter(c=>c.department===d);return <div className="card dept" key={d}><div className="dept-icon"><Building2/></div><h2>{d}</h2><p>{list.length} assigned complaint{list.length!==1?"s":""}</p><div className="mini-bar"><span style={{width:`${Math.min(100, list.length*20+15)}%`}}/></div><small>Active workload</small></div>})}</div>
  </div>
}

function Reports({complaints}:{complaints:Complaint[]}) {
  const categories=[...new Set(complaints.map(c=>c.category))];
  return <div className="content"><div className="page-head"><div><p className="eyebrow">ANALYTICS</p><h1>Service Performance Report</h1><p className="muted">A quick summary of complaint categories, priority and resolution.</p></div></div>
    <div className="report-grid"><div className="card big-report"><h2>Resolution Overview</h2><div className="donut"><strong>{complaints.length?Math.round((complaints.filter(c=>c.status==="Resolved").length/complaints.length)*100):0}%</strong><span>resolved</span></div><div className="legend"><span><i/>Resolved <b>{complaints.filter(c=>c.status==="Resolved").length}</b></span><span><i/>Open <b>{complaints.filter(c=>c.status!=="Resolved").length}</b></span></div></div>
      <div className="card"><h2>Complaints by Category</h2><div className="bars">{categories.map(cat=>{const n=complaints.filter(c=>c.category===cat).length;return <div className="bar-row" key={cat}><div><span>{cat}</span><b>{n}</b></div><div className="bar"><span style={{width:`${Math.max(8,n/Math.max(1,complaints.length)*100)}%`}}/></div></div>})}</div></div>
    </div>
    <div className="card report-table"><h2>Priority Distribution</h2><div className="priority-grid">{(["Critical","High","Medium","Low"] as Complaint["priority"][]).map(p=><div key={p}><Priority value={p}/><strong>{complaints.filter(c=>c.priority===p).length}</strong><small>complaints</small></div>)}</div></div>
  </div>
}

function Modal({children,onClose}:{children:React.ReactNode;onClose:()=>void}) {
  return <div className="modal-backdrop"><div className="modal"><button className="close icon-btn" onClick={onClose}><X/></button>{children}</div></div>
}

export default App;
